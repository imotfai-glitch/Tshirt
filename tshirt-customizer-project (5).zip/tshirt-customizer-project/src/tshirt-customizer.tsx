import React, { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Switch } from "@/components/ui/switch";
import { ShoppingCart, Plus, Type, Image as ImageIcon, Trash2, RotateCcw, Download } from "lucide-react";

const DEFAULT_FONT = "Inter, system-ui, Avenir, Helvetica, Arial, sans-serif";

function uid() {
  return Math.random().toString(36).slice(2, 9);
}

const BASE_PRICE = 14.9;

function estimatePrice(layers, printAreaWidth, printAreaHeight, dpi) {
  const inchesW = printAreaWidth / dpi;
  const inchesH = printAreaHeight / dpi;
  const area = Math.max(6, Math.min(12 * 12, inchesW * inchesH));
  const areaFactor = 0.25 * (area / 50);
  const layerCost = layers.length * 1.2;
  return +(BASE_PRICE + areaFactor + layerCost).toFixed(2);
}

export default function TShirtCustomizerApp() {
  const canvasRef = useRef(null);
  const [tshirtColor, setTshirtColor] = useState("#ffffff");
  const [tshirtSize, setTshirtSize] = useState("M");
  const [dpi] = useState(150);
  const [area, setArea] = useState({ width: 360, height: 420 });
  const [layers, setLayers] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const selectedLayer = useMemo(() => layers.find(l => l.id === selectedId) || null, [layers, selectedId]);
  const [dragState, setDragState] = useState(null);
  const [showGrid, setShowGrid] = useState(true);
  const price = useMemo(() => estimatePrice(layers, area.width, area.height, 72), [layers, area]);

  function addTextLayer() {
    const id = uid();
    setLayers(prev => [...prev, {
      id,
      type: "text",
      text: "Text nou",
      x: 50,
      y: 50,
      fontSize: 24,
      fontFamily: DEFAULT_FONT,
      color: "#000000"
    }]);
    setSelectedId(id);
  }

  function addImageLayer(url) {
    const id = uid();
    setLayers(prev => [...prev, {
      id,
      type: "image",
      url,
      x: 60,
      y: 60,
      width: 100,
      height: 100
    }]);
    setSelectedId(id);
  }

  function deleteLayer(id) {
    setLayers(prev => prev.filter(l => l.id !== id));
    setSelectedId(null);
  }

  function updateLayer(id, updates) {
    setLayers(prev => prev.map(l => l.id === id ? { ...l, ...updates } : l));
  }

  function resetDesign() {
    setLayers([]);
    setSelectedId(null);
  }

  return (
    <div className="p-4 space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Personalizează tricoul tău</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col md:flex-row gap-4">
          <div className="flex flex-col gap-2 w-full md:w-2/3 items-center">
            <div className="relative border border-gray-300" style={{ backgroundColor: tshirtColor, width: area.width, height: area.height }}>
              {showGrid && (
                <div className="absolute inset-0 bg-[linear-gradient(to_right,transparent_95%,rgba(0,0,0,0.05)_95%),linear-gradient(to_bottom,transparent_95%,rgba(0,0,0,0.05)_95%)] bg-[size:20px_20px] pointer-events-none" />
              )}
              {layers.map(layer => (
                <div key={layer.id}
                  className="absolute cursor-move"
                  style={{ top: layer.y, left: layer.x }}
                  onClick={() => setSelectedId(layer.id)}
                >
                  {layer.type === "text" ? (
                    <span style={{ fontSize: layer.fontSize, fontFamily: layer.fontFamily, color: layer.color }}>{layer.text}</span>
                  ) : (
                    <img src={layer.url} alt="" style={{ width: layer.width, height: layer.height }} />
                  )}
                </div>
              ))}
            </div>
          </div>
          <div className="flex flex-col gap-4 w-full md:w-1/3">
            <div className="space-y-2">
              <Label>Culoare tricou</Label>
              <Input type="color" value={tshirtColor} onChange={(e) => setTshirtColor(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Mărime tricou</Label>
              <Select value={tshirtSize} onValueChange={setTshirtSize}>
                <SelectTrigger><SelectValue placeholder="Alege mărimea" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="S">S</SelectItem>
                  <SelectItem value="M">M</SelectItem>
                  <SelectItem value="L">L</SelectItem>
                  <SelectItem value="XL">XL</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Adaugă text / imagine</Label>
              <div className="flex gap-2">
                <Button onClick={addTextLayer}><Type className="w-4 h-4 mr-2" /> Text</Button>
                <Button onClick={() => addImageLayer(prompt("URL imagine:"))}><ImageIcon className="w-4 h-4 mr-2" /> Imagine</Button>
              </div>
            </div>
            {selectedLayer && (
              <div className="space-y-2">
                <Label>Setări pentru elementul selectat</Label>
                {selectedLayer.type === "text" ? (
                  <>
                    <Input value={selectedLayer.text} onChange={(e) => updateLayer(selectedLayer.id, { text: e.target.value })} />
                    <Input type="color" value={selectedLayer.color} onChange={(e) => updateLayer(selectedLayer.id, { color: e.target.value })} />
                  </>
                ) : null}
                <Button variant="destructive" onClick={() => deleteLayer(selectedLayer.id)}><Trash2 className="w-4 h-4 mr-2" /> Șterge</Button>
              </div>
            )}
            <div className="flex items-center justify-between">
              <span className="text-sm">Arată grila</span>
              <Switch checked={showGrid} onCheckedChange={setShowGrid} />
            </div>
            <div className="font-semibold">Preț estimativ: ${price}</div>
            <Button variant="outline" onClick={resetDesign}><RotateCcw className="w-4 h-4 mr-2" /> Resetează</Button>
            <Button variant="default"><ShoppingCart className="w-4 h-4 mr-2" /> Comandă</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}